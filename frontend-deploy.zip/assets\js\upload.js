/* ============================================================
   FruGrade — Upload & Camera Capture Page
   Shared Flow: Device Upload OR Camera Capture
   → Image Validation → Image Preview → User Confirmation
   → Analyze Fruit → Processing → Prediction Result
   ============================================================ */
(function () {
  'use strict';

  window.FG = window.FG || {};

  var $ = FG.util.$;
  var $$ = FG.util.$$;

  var dom = {};
  var state = {
    file: null,
    dims: null,
    previewUrl: null,
    busy: false,
    activeTab: 'upload', // 'upload' | 'camera'
    stageTimers: [],
    progressTimer: null,
    selectedDemoScenario: null
  };

  function t(key, fallback) {
    if (FG.i18n && typeof FG.i18n.t === 'function') {
      return FG.i18n.t(key, fallback);
    }
    return fallback != null ? fallback : key;
  }

  /* ---------------- Camera State & Controller ---------------- */
  var camera = {
    stream: null,
    facingMode: 'environment', // prefer rear camera on mobile
    isOpen: false,
    isMirrored: false,
    availableVideoInputs: 0,

    open: function () {
      setTab('camera');

      // Check secure context
      if (typeof window.isSecureContext !== 'undefined' && !window.isSecureContext) {
        camera.showError('INSECURE_CONTEXT', t('msg.cameraInsecure', 'Camera access requires a secure connection (HTTPS or localhost). Please upload an image instead.'));
        return;
      }

      // Check browser MediaDevices support
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        camera.showError('NOT_SUPPORTED', t('msg.cameraUnsupported', 'Live camera preview is not supported in this browser. Please use the device camera upload option or select a file.'));
        return;
      }

      camera.isOpen = true;
      camera.hideError();

      // Restore user-saved mirror preference
      try {
        camera.isMirrored = localStorage.getItem('frugrade_camera_mirrored') === '1';
      } catch (e) {
        camera.isMirrored = false;
      }
      camera.applyMirror();

      if (dom.cameraLoading) dom.cameraLoading.classList.remove('hidden');

      camera.startStream();
    },

    applyMirror: function () {
      if (dom.cameraVideo) {
        dom.cameraVideo.style.transform = camera.isMirrored ? 'scaleX(-1)' : 'scaleX(1)';
      }
      if (dom.cameraMirrorLabel) {
        dom.cameraMirrorLabel.textContent = camera.isMirrored
          ? t('upload.mirrorActive', 'Cermin Aktif')
          : t('upload.mirrorNormal', 'Normal');
      }
      if (dom.cameraMirrorChip) {
        dom.cameraMirrorChip.classList.toggle('!bg-strawberry-red', camera.isMirrored);
        dom.cameraMirrorChip.classList.toggle('!text-white', camera.isMirrored);
      }
      if (dom.btnMirrorCamera) {
        dom.btnMirrorCamera.setAttribute('aria-pressed', camera.isMirrored ? 'true' : 'false');
        dom.btnMirrorCamera.classList.toggle('!bg-surface-container', camera.isMirrored);
        dom.btnMirrorCamera.classList.toggle('text-forest-green', camera.isMirrored);
        dom.btnMirrorCamera.classList.toggle('font-bold', camera.isMirrored);
      }
    },

    toggleMirror: function (silent) {
      camera.isMirrored = !camera.isMirrored;
      try {
        localStorage.setItem('frugrade_camera_mirrored', camera.isMirrored ? '1' : '0');
      } catch (e) {}
      camera.applyMirror();
      if (!silent) {
        var msg = camera.isMirrored
          ? t('msg.mirrorEnabled', 'Cermin aktif (dibalik horizontal).')
          : t('msg.mirrorDisabled', 'Cermin nonaktif (tampilan normal).');
        FG.util.toast(msg, { duration: 1800 });
      }
    },

    startStream: function () {
      camera.stopStream();

      // Check available cameras on device
      if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
        navigator.mediaDevices.enumerateDevices().then(function (devices) {
          var vids = devices.filter(function (d) { return d.kind === 'videoinput'; });
          camera.availableVideoInputs = vids.length;
        }).catch(function () {});
      }

      var constraints = {
        audio: false, // Video only; never request audio
        video: {
          facingMode: { ideal: camera.facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      };

      navigator.mediaDevices.getUserMedia(constraints)
        .catch(function () {
          // Fallback without width/height constraints if device is strict
          return navigator.mediaDevices.getUserMedia({
            audio: false,
            video: { facingMode: { ideal: camera.facingMode } }
          });
        })
        .catch(function () {
          // Broadest fallback: any video device
          return navigator.mediaDevices.getUserMedia({ audio: false, video: true });
        })
        .then(function (stream) {
          camera.stream = stream;
          if (dom.cameraVideo) {
            dom.cameraVideo.srcObject = stream;
            camera.applyMirror();
            dom.cameraVideo.onloadedmetadata = function () {
              dom.cameraVideo.play().catch(function () {});
              camera.applyMirror();
              if (dom.cameraLoading) dom.cameraLoading.classList.add('hidden');
            };
          }
        })
        .catch(function (err) {
          console.error('Camera access error:', err);
          camera.handleError(err);
        });
    },

    handleError: function (err) {
      if (dom.cameraLoading) dom.cameraLoading.classList.add('hidden');
      var name = (err && err.name) || '';
      var message = t('msg.cameraNotFound', 'Unable to access camera. Please upload an image instead.');

      if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
        message = t('msg.cameraPermissionDenied', 'Camera permission was denied. Please allow camera access in your browser settings or use Upload Image.');
      } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
        message = t('msg.cameraNotFound', 'No camera detected on this device. Please use Upload Image instead.');
      } else if (name === 'NotReadableError' || name === 'TrackStartError') {
        message = t('msg.cameraInUse', 'Camera is currently in use by another application. Please close other camera apps and try again.');
      } else if (name === 'OverconstrainedError') {
        message = t('msg.cameraUnsupported', 'The requested camera mode is not supported by your device hardware.');
      }

      camera.showError(name || 'CAMERA_ERROR', message);
    },

    showError: function (code, message) {
      if (dom.cameraError) {
        dom.cameraError.hidden = false;
        dom.cameraError.classList.remove('hidden');
      }
      if (dom.cameraErrorMsg) {
        dom.cameraErrorMsg.textContent = message;
      }
      FG.util.toast(message, { type: 'error', duration: 5000 });
    },

    hideError: function () {
      if (dom.cameraError) {
        dom.cameraError.hidden = true;
        dom.cameraError.classList.add('hidden');
      }
    },

    stopStream: function () {
      if (camera.stream) {
        camera.stream.getTracks().forEach(function (track) {
          try { track.stop(); } catch (e) {}
        });
        camera.stream = null;
      }
      if (dom.cameraVideo) {
        dom.cameraVideo.srcObject = null;
      }
    },

    close: function () {
      camera.stopStream();
      camera.isOpen = false;
      camera.hideError();
      setTab('upload');
    },

    flip: function () {
      // If single camera detected (e.g. laptop webcam), flip action toggles mirror orientation
      if (camera.availableVideoInputs <= 1 && camera.stream) {
        camera.toggleMirror(true);
        FG.util.toast(t('msg.singleCameraFlip', 'Hanya 1 kamera terdeteksi di perangkat. Orientasi cermin dibalik.'), { duration: 2200 });
        return;
      }
      camera.facingMode = (camera.facingMode === 'environment') ? 'user' : 'environment';
      camera.startStream();
      FG.util.toast(t('msg.cameraSwitched', 'Mengalihkan kamera: ') + (camera.facingMode === 'user' ? 'Depan' : 'Belakang'), { duration: 1800 });
    },

    capture: function () {
      if (!dom.cameraVideo || !camera.stream) return;

      // Visual flash feedback
      if (dom.cameraFlash) {
        dom.cameraFlash.classList.remove('opacity-0');
        dom.cameraFlash.classList.add('opacity-80');
        window.setTimeout(function () {
          dom.cameraFlash.classList.remove('opacity-80');
          dom.cameraFlash.classList.add('opacity-0');
        }, 160);
      }

      var vw = dom.cameraVideo.videoWidth || 640;
      var vh = dom.cameraVideo.videoHeight || 480;

      if (dom.cameraCanvas) {
        dom.cameraCanvas.width = vw;
        dom.cameraCanvas.height = vh;
        var ctx = dom.cameraCanvas.getContext('2d');
        if (camera.isMirrored) {
          ctx.save();
          ctx.translate(vw, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(dom.cameraVideo, 0, 0, vw, vh);
          ctx.restore();
        } else {
          ctx.drawImage(dom.cameraVideo, 0, 0, vw, vh);
        }

        dom.cameraCanvas.toBlob(function (blob) {
          if (!blob) {
            FG.util.toast(t('msg.cameraCaptureFailed', 'Failed to capture frame from camera.'), { type: 'error' });
            return;
          }

          var filename = 'camera-fruit-' + Date.now() + '.jpg';
          var file;
          try {
            file = new File([blob], filename, { type: 'image/jpeg', lastModified: Date.now() });
          } catch (e) {
            blob.name = filename;
            file = blob;
          }

          // Stop all camera tracks immediately after capturing
          camera.stopStream();
          camera.isOpen = false;

          // Route through the EXACT same handleFile() function (resetting demo scenario)
          state.selectedDemoScenario = null;
          if (FG.api) FG.api.forcedScenario = null;
          $$('[data-demo]').forEach(function (b) { b.removeAttribute('aria-pressed'); });
          handleFile(file).then(function (ok) {
            if (ok) {
              FG.util.toast(t('msg.cameraCaptured', 'Photo captured successfully from camera!'), { duration: 2500 });
            }
          });
        }, 'image/jpeg', 0.92);
      }
    }
  };

  /* ---------------- DOM Cache ---------------- */
  function cache() {
    dom.input = $('#file-input');
    dom.cameraInput = $('#camera-input');
    dom.tabUpload = $('#tab-upload');
    dom.tabCamera = $('#tab-camera');
    dom.viewUpload = $('#view-upload');
    dom.viewCamera = $('#view-camera');
    dom.dropzone = $('#dropzone');
    dom.btnBrowse = $('#btn-browse-file');

    dom.cameraVideo = $('#camera-video');
    dom.cameraCanvas = $('#camera-canvas');
    dom.cameraFlash = $('#camera-flash');
    dom.cameraLoading = $('#camera-loading');
    dom.cameraError = $('#camera-error');
    dom.cameraErrorMsg = $('#camera-error-msg');
    dom.btnCameraFallback = $('#btn-camera-fallback');
    dom.btnCameraSwitchUpload = $('#btn-camera-switch-upload');
    dom.btnCancelCamera = $('#btn-cancel-camera');
    dom.btnCaptureCamera = $('#btn-capture-camera');
    dom.btnMirrorCamera = $('#btn-mirror-camera');
    dom.btnFlipCamera = $('#btn-flip-camera');
    dom.cameraMirrorChip = $('#camera-mirror-chip');
    dom.cameraMirrorLabel = $('#camera-mirror-label');

    dom.previewCard = $('#preview-card');
    dom.previewEmpty = $('#preview-empty');
    dom.previewFilled = $('#preview-filled');
    dom.image = $('#preview-image');
    dom.fileName = $('#file-name');
    dom.fileMeta = $('#file-meta');
    dom.fileDims = $('#file-dims');
    dom.previewCardTitle = $('#preview-card-title');
    dom.replace = $('#btn-replace');
    dom.retakeCamera = $('#btn-retake-camera');
    dom.remove = $('#btn-remove');
    dom.analyze = $('#analyze-btn');
    dom.analyzeHint = $('#analyze-hint');

    dom.processing = $('#processing');
    dom.progressFill = $('#progress-fill');
    dom.progressPct = $('#progress-pct');
    dom.progressLabel = $('#progress-label');
    dom.errorPanel = $('#error-panel');
    dom.errorTitle = $('#error-title');
    dom.errorCode = $('#error-code');
    dom.errorMessage = $('#error-message');
    dom.retry = $('#error-retry');
    dom.statusChip = $('#upload-status');
    dom.statusChipText = $('#upload-status-text');
    dom.stageList = $('#stage-list');
    dom.scanOverlay = $('#preview-scan');
    dom.mascot = $('#upload-mascot');
  }

  /* ---------------- Tab Switching ---------------- */
  function setTab(tab) {
    state.activeTab = tab;

    if (tab === 'upload') {
      if (dom.tabUpload) {
        dom.tabUpload.setAttribute('aria-selected', 'true');
        dom.tabUpload.className = 'flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 py-2 font-label-md text-label-md font-semibold transition-all duration-200 bg-surface-container-lowest text-forest-green shadow-soft';
      }
      if (dom.tabCamera) {
        dom.tabCamera.setAttribute('aria-selected', 'false');
        dom.tabCamera.className = 'flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 py-2 font-label-md text-label-md font-medium text-on-surface-variant transition-all duration-200 hover:text-soft-charcoal';
      }
      if (dom.viewUpload) {
        dom.viewUpload.hidden = false;
        dom.viewUpload.classList.remove('hidden');
      }
      if (dom.viewCamera) {
        dom.viewCamera.hidden = true;
        dom.viewCamera.classList.add('hidden');
      }
      camera.stopStream();
      camera.isOpen = false;
    } else if (tab === 'camera') {
      if (dom.tabCamera) {
        dom.tabCamera.setAttribute('aria-selected', 'true');
        dom.tabCamera.className = 'flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 py-2 font-label-md text-label-md font-semibold transition-all duration-200 bg-surface-container-lowest text-forest-green shadow-soft';
      }
      if (dom.tabUpload) {
        dom.tabUpload.setAttribute('aria-selected', 'false');
        dom.tabUpload.className = 'flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 py-2 font-label-md text-label-md font-medium text-on-surface-variant transition-all duration-200 hover:text-soft-charcoal';
      }
      if (dom.viewCamera) {
        dom.viewCamera.hidden = false;
        dom.viewCamera.classList.remove('hidden');
      }
      if (dom.viewUpload) {
        dom.viewUpload.hidden = true;
        dom.viewUpload.classList.add('hidden');
      }
    }
  }

  /* ---------------- Helpers ---------------- */
  function setActionButtonsDisabled(disabled) {
    var btns = [dom.replace, dom.retakeCamera, dom.remove];
    btns.forEach(function (btn) {
      if (!btn) return;
      btn.disabled = !!disabled;
      btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
      if (disabled) {
        btn.classList.add('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
      } else {
        btn.classList.remove('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
      }
    });

    $$('[data-demo]').forEach(function (btn) {
      btn.disabled = !!disabled;
      btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
      if (disabled) {
        btn.classList.add('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
      } else {
        btn.classList.remove('opacity-40', 'cursor-not-allowed', 'pointer-events-none');
      }
    });
  }

  function setAnalyzeEnabled(on) {
    if (!dom.analyze) return;
    dom.analyze.disabled = !on;
    dom.analyze.setAttribute('aria-disabled', on ? 'false' : 'true');
    dom.analyze.classList.toggle('is-ready', !!on);
    if (dom.analyzeHint) {
      dom.analyzeHint.textContent = on
        ? t('upload.hintReady', 'Gambar siap dianalisis. Klik tombol untuk memulai pemindaian.')
        : t('upload.hintEmpty', 'Pilih atau potret gambar terlebih dahulu untuk mengaktifkan pemindaian.');
    }
  }

  function clearError() {
    if (!dom.errorPanel) return;
    dom.errorPanel.hidden = true;
    dom.errorPanel.classList.add('is-hidden');
    if (dom.errorTitle) {
      dom.errorTitle.textContent = t('upload.errorTitle', 'Analisis gagal');
    }
  }

  function showError(code, message) {
    if (!dom.errorPanel) return;
    dom.errorPanel.hidden = false;
    dom.errorPanel.classList.remove('is-hidden');
    if (dom.errorTitle) {
      var isFileCheck = /^(UNREADABLE_IMAGE|INVALID_FORMAT|EMPTY_FILE|FILE_TOO_LARGE|IMAGE_TOO_SMALL)$/.test(code || '');
      dom.errorTitle.textContent = isFileCheck
        ? t('upload.fileErrorTitle', 'Berkas tidak valid')
        : t('upload.errorTitle', 'Analisis gagal');
    }
    if (dom.errorCode) dom.errorCode.textContent = code || 'ERROR';
    if (dom.errorMessage) dom.errorMessage.textContent = message;
    FG.util.toast(message, { type: 'error', duration: 5000 });
    if (dom.mascot) FG.fruit.setMood(dom.mascot, 'oops');
    window.setTimeout(function () { if (dom.mascot) FG.fruit.setMood(dom.mascot, null); }, 1800);
    if (!/^(NO_FILE)$/.test(code || '')) {
      window.setTimeout(function () {
        dom.errorPanel.scrollIntoView({ behavior: FG.util.prefersReduced() ? 'auto' : 'smooth', block: 'nearest' });
      }, 80);
    }
  }

  function validate(file) {
    var cfg = FG.config;
    if (!file) return { ok: false, code: 'NO_FILE', message: t('msg.noFile', 'No image selected.') };

    var ext = FG.util.ext(file.name);
    var mimeOk = file.type && cfg.acceptedTypes.indexOf(file.type) !== -1;
    var extOk = cfg.acceptedExt.indexOf(ext) !== -1;

    // Allow image/jpeg or image/png blobs
    if (!mimeOk && !extOk && file.type && file.type.indexOf('image/') === 0) {
      mimeOk = true;
    }

    if (!mimeOk && !extOk) {
      return {
        ok: false,
        code: 'INVALID_FORMAT',
        message: t('msg.invalidFormat', 'Unsupported format. Please use JPG, JPEG, or PNG images.')
      };
    }
    if (file.size === 0) {
      return { ok: false, code: 'EMPTY_FILE', message: t('msg.emptyFile', 'File is empty or cannot be read.') };
    }
    if (file.size > cfg.maxFileMB * 1024 * 1024) {
      return {
        ok: false,
        code: 'FILE_TOO_LARGE',
        message: t('msg.fileTooLarge', 'File size exceeds ' + cfg.maxFileMB + ' MB. Please compress your image.')
      };
    }
    return { ok: true };
  }

  function decode(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        resolve({ url: url, width: img.naturalWidth, height: img.naturalHeight });
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error(t('msg.unreadableImage', 'Berkas gambar rusak atau korup sehingga tidak dapat dibaca. Silakan pilih foto lain dengan format JPG atau PNG yang jelas.')));
      };
      img.src = url;
    });
  }

  function releasePreview() {
    if (state.previewUrl) {
      URL.revokeObjectURL(state.previewUrl);
      state.previewUrl = null;
    }
  }

  /* ---------------- Preview ---------------- */
  function renderPreview(file, info) {
    releasePreview();
    state.previewUrl = info.url;

    dom.image.src = info.url;
    dom.image.alt = 'Fruit photo preview: ' + (file.name || 'Captured photo');

    if (dom.fileName) dom.fileName.textContent = file.name || 'camera-capture.jpg';
    if (dom.fileMeta) dom.fileMeta.textContent = FG.util.formatBytes(file.size) + ' • ' + info.width + ' × ' + info.height + ' px';
    if (dom.fileDims) dom.fileDims.textContent = info.width + ' × ' + info.height;

    dom.previewEmpty.classList.add('is-hidden');
    dom.previewEmpty.hidden = true;
    dom.previewFilled.hidden = false;
    dom.previewFilled.classList.remove('is-hidden');

    var media = dom.previewFilled.querySelector('.preview-media');
    if (media && !FG.util.prefersReduced()) {
      media.classList.add('is-wiping');
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          media.classList.remove('is-wiping');
          media.classList.add('is-shown');
        });
      });
    } else if (media) {
      media.classList.add('is-shown');
    }

    if (dom.statusChip) {
      dom.statusChip.className = 'chip chip-fresh';
      dom.statusChip.innerHTML = '<span class="icon text-[15px]">check_circle</span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.readyStatus', 'Gambar siap dianalisis')) + '</span>';
    }
    if (dom.previewCardTitle) {
      dom.previewCardTitle.textContent = t('upload.readyCardTitle', 'Gambar siap dianalisis');
    }

    setActionButtonsDisabled(false);
    setAnalyzeEnabled(true);
    if (dom.analyze) {
      dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
    }
    clearError();

    if (dom.mascot) {
      FG.fruit.setMood(dom.mascot, 'excited');
      window.setTimeout(function () { if (dom.mascot) FG.fruit.setMood(dom.mascot, null); }, 1200);
    }
  }

  function resetPreview() {
    releasePreview();
    state.file = null;
    state.dims = null;
    state.selectedDemoScenario = null;
    if (FG.api) FG.api.forcedScenario = null;
    $$('[data-demo]').forEach(function (b) { b.removeAttribute('aria-pressed'); });

    if (dom.input) dom.input.value = '';
    if (dom.cameraInput) dom.cameraInput.value = '';
    if (dom.image) dom.image.removeAttribute('src');

    dom.previewFilled.hidden = true;
    dom.previewFilled.classList.add('is-hidden');
    dom.previewEmpty.hidden = false;
    dom.previewEmpty.classList.remove('is-hidden');

    var media = dom.previewFilled.querySelector('.preview-media');
    if (media) media.classList.remove('is-shown');

    if (dom.statusChip) {
      dom.statusChip.className = 'chip chip-neutral';
      dom.statusChip.innerHTML = '<span class="dot"></span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.waitingStatus', 'Waiting for image')) + '</span>';
    }
    if (dom.previewCardTitle) {
      dom.previewCardTitle.textContent = t('upload.readyCardTitle', 'Gambar siap dianalisis');
    }

    hideProcessing();
    clearError();
    setActionButtonsDisabled(false);
    setAnalyzeEnabled(false);
    if (dom.analyze) {
      dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
    }

    if (dom.mascot) FG.fruit.setMood(dom.mascot, null);
  }

  /* ---------------- Processing ---------------- */
  function setProgress(pct) {
    var p = FG.util.clamp(pct, 0, 100);
    if (dom.progressFill) dom.progressFill.style.width = p + '%';
    if (dom.progressPct) dom.progressPct.textContent = Math.round(p) + '%';
  }

  function resetStages() {
    if (!dom.stageList) return;
    $$('[data-stage]', dom.stageList).forEach(function (el, i) {
      el.classList.remove('is-active', 'is-done');
      var icon = el.querySelector('.stage-icon');
      if (icon) {
        icon.classList.remove('icon');
        icon.textContent = String(i + 1);
      }
    });
  }

  function markStage(index, done) {
    if (!dom.stageList) return;
    var stages = $$('[data-stage]', dom.stageList);
    stages.forEach(function (el, i) {
      if (i < index) el.classList.add('is-done');
      el.classList.toggle('is-active', i === index && !done);
      if (i === index && done) {
        el.classList.remove('is-active');
        el.classList.add('is-done');
      }
    });
    stages.forEach(function (el, i) {
      var icon = el.querySelector('.stage-icon');
      if (!icon) return;
      if (el.classList.contains('is-done')) {
        icon.classList.add('icon');
        icon.textContent = 'check';
      } else if (!el.classList.contains('is-active')) {
        icon.classList.remove('icon');
        icon.textContent = String(i + 1);
      }
    });
  }

  function completeStages() {
    if (!dom.stageList) return;
    $$('[data-stage]', dom.stageList).forEach(function (el, i) {
      el.classList.remove('is-active');
      el.classList.add('is-done');
      var icon = el.querySelector('.stage-icon');
      if (icon) {
        icon.classList.add('icon');
        icon.textContent = 'check';
      }
    });
  }

  function stageLabel(idx) {
    return [
      t('upload.stage1', 'Validating format & readability…'),
      t('upload.stage2', 'Preprocessing 224 × 224 RGB…'),
      t('upload.stage3', 'Running CNN inference (TensorFlow / Keras)…'),
      t('upload.stage4', 'Computing 12-class confidence scores…')
    ][idx] || t('upload.processingTitle', 'Processing…');
  }

  function startProcessing() {
    if (!dom.processing) return;
    dom.processing.hidden = false;
    dom.processing.classList.remove('is-hidden');
    resetStages();
    setProgress(4);
    if (dom.progressFill) dom.progressFill.classList.remove('is-error');
    if (dom.scanOverlay) dom.scanOverlay.classList.remove('is-hidden');

    window.setTimeout(function () {
      dom.processing.scrollIntoView({ behavior: FG.util.prefersReduced() ? 'auto' : 'smooth', block: 'nearest' });
    }, 120);

    var slow = (FG.api.forcedScenario || FG.config.scenario) === 'slow';
    var factor = slow ? 2.7 : 1;
    var stageOffsets = [0, 620 * factor, 1320 * factor, 2050 * factor];

    state.stageTimers.forEach(clearTimeout);
    state.stageTimers = [];

    stageOffsets.forEach(function (delay, idx) {
      state.stageTimers.push(window.setTimeout(function () {
        markStage(idx, false);
        if (dom.progressLabel) dom.progressLabel.textContent = stageLabel(idx);
      }, delay));
    });

    clearInterval(state.progressTimer);
    state.progressTimer = window.setInterval(function () {
      var current = parseFloat(dom.progressFill ? dom.progressFill.style.width : '0') || 0;
      if (current >= 92) return;
      setProgress(current + (92 - current) * 0.09 + 0.4);
    }, 180);
  }

  function hideProcessing() {
    state.stageTimers.forEach(clearTimeout);
    state.stageTimers = [];
    clearInterval(state.progressTimer);
    if (!dom.processing) return;
    dom.processing.hidden = true;
    dom.processing.classList.add('is-hidden');
    if (dom.scanOverlay) dom.scanOverlay.classList.add('is-hidden');
    setProgress(0);
  }

  function finishProcessing() {
    completeStages();
    setProgress(100);
    if (dom.progressLabel) dom.progressLabel.textContent = t('upload.stageDone', 'Done. Opening results…');
    clearInterval(state.progressTimer);
  }

  /* ---------------- Shared File Handling ---------------- */
  // Unified flow: Device Upload OR Camera Capture passes through here
  function handleFile(file) {
    if (state.busy) return Promise.resolve(false);

    var check = validate(file);
    if (!check.ok) {
      if (dom.dropzone) {
        dom.dropzone.classList.add('is-invalid');
        window.setTimeout(function () { dom.dropzone.classList.remove('is-invalid'); }, 700);
      }
      resetPreview();
      showError(check.code, check.message);
      return Promise.resolve(false);
    }

    if (dom.input) dom.input.value = '';
    if (dom.cameraInput) dom.cameraInput.value = '';

    return decode(file)
      .then(function (info) {
        if (info.width < FG.config.minDimension || info.height < FG.config.minDimension) {
          URL.revokeObjectURL(info.url);
          resetPreview();
          showError(
            'IMAGE_TOO_SMALL',
            t('msg.imageTooSmall', 'Resolusi gambar terlalu kecil (' + info.width + ' × ' + info.height + ' px). Minimal ' + FG.config.minDimension + ' px.')
          );
          return false;
        }
        state.file = file;
        state.dims = { width: info.width, height: info.height };
        renderPreview(file, info);

        if (dom.previewCard && window.innerWidth < 1024) {
          dom.previewCard.scrollIntoView({ behavior: FG.util.prefersReduced() ? 'auto' : 'smooth', block: 'center' });
        }
        return true;
      })
      .catch(function () {
        resetPreview();
        showError('UNREADABLE_IMAGE', t('msg.unreadableImage', 'Berkas gambar rusak atau korup sehingga tidak dapat dibaca. Silakan pilih foto lain dengan format JPG atau PNG yang jelas.'));
        return false;
      });
  }

  /* ---------------- Demo Scenarios Selection & Execution ---------------- */
  /**
   * Hanya memilih skenario dan menampilkan preview gambar.
   * SAMA SEKALI TIDAK menjalankan simulasi atau analisis.
   */
  function selectDemoScenario(scenario, fruit, evt) {
    if (evt) {
      if (typeof evt.preventDefault === 'function') evt.preventDefault();
      if (typeof evt.stopPropagation === 'function') evt.stopPropagation();
    }
    if (state.busy) return;

    // 1. Simpan skenario yang dipilih
    state.selectedDemoScenario = scenario;
    if (FG.api) FG.api.forcedScenario = scenario;

    // 2. Tandai status tombol demo secara visual
    $$('[data-demo]').forEach(function (btn) {
      var isThis = btn.getAttribute('data-demo') === scenario;
      btn.setAttribute('aria-pressed', isThis ? 'true' : 'false');
    });

    var fruitName = fruit || (scenario === 'rotten' ? 'banana' : (scenario === 'error' ? 'corrupted' : 'apple'));

    // 3. Muat gambar contoh dan tampilkan pada preview
    var triggerBtn = evt && evt.currentTarget ? evt.currentTarget : $('[data-demo="' + scenario + '"]');
    if (triggerBtn) triggerBtn.setAttribute('aria-busy', 'true');

    FG.api.sampleFile(fruitName)
      .then(function (file) {
        return handleFile(file);
      })
      .then(function (ok) {
        if (ok) {
          if (scenario === 'error') {
            // Skenario Simulasi Gagal: Tampilkan status skenario simulasi, tombol Pindai Buah tetap aktif
            if (dom.statusChip) {
              dom.statusChip.className = 'chip chip-demo';
              dom.statusChip.innerHTML = '<span class="icon text-[15px]">science</span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.demoErrorStatus', 'Skenario simulasi kegagalan')) + '</span>';
            }
            if (dom.previewCardTitle) {
              dom.previewCardTitle.textContent = t('upload.demoErrorCardTitle', 'Skenario simulasi kegagalan');
            }
            setAnalyzeEnabled(true);
            if (dom.analyzeHint) {
              dom.analyzeHint.textContent = t('upload.hintDemoErrorReady', 'Skenario simulasi siap. Klik Pindai Buah untuk menguji simulasi kegagalan proses.');
            }
            setActionButtonsDisabled(false);
            clearError();
            hideProcessing();
            if (dom.mascot) FG.fruit.setMood(dom.mascot, null);
          } else {
            // Skenario Segar / Busuk: Status Siap & tombol Pindai Buah aktif
            if (dom.statusChip) {
              dom.statusChip.className = 'chip chip-fresh';
              dom.statusChip.innerHTML = '<span class="icon text-[15px]">check_circle</span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.readyStatus', 'Gambar siap dianalisis')) + '</span>';
            }
            if (dom.previewCardTitle) {
              dom.previewCardTitle.textContent = t('upload.readyCardTitle', 'Gambar siap dianalisis');
            }
            setAnalyzeEnabled(true);
            if (dom.analyzeHint) {
              dom.analyzeHint.textContent = t('upload.hintReady', 'Gambar siap dianalisis. Klik tombol untuk memulai pemindaian.');
            }
            setActionButtonsDisabled(false);
            clearError();
            hideProcessing();
            if (dom.mascot) FG.fruit.setMood(dom.mascot, 'excited');
          }

          if (dom.previewContainer && window.innerWidth < 1024) {
            dom.previewContainer.scrollIntoView({ behavior: FG.util.prefersReduced() ? 'auto' : 'smooth', block: 'start' });
          }
        }
      })
      .catch(function () {
        FG.util.toast(t('msg.sampleLoadFailed', 'Failed to load sample. Run via local server (npm run dev).'), { type: 'error' });
      })
      .then(function () {
        if (triggerBtn) triggerBtn.removeAttribute('aria-busy');
      });

    // PENTING: Sama sekali tidak memanggil analyze() atau setTimeout di sini!
  }

  /**
   * Menjalankan simulasi demo hasil buah segar, buah busuk, atau error.
   * HANYA dipanggil setelah pengguna menekan tombol Pindai Buah secara manual.
   */
  function executeDemoScenario(scenario) {
    if (FG.api) FG.api.forcedScenario = scenario;
    return FG.api
      .predict(state.file)
      .then(function (result) {
        return FG.store.makeThumb(state.file, 900).then(function (thumb) {
          return { result: result, thumb: thumb };
        });
      })
      .then(function (payload) {
        finishProcessing();
        var saved = FG.store.save({
          result: payload.result,
          image: payload.thumb.dataUrl,
          file: {
            name: state.file.name || 'sample.jpg',
            size: state.file.size,
            width: payload.thumb.width,
            height: payload.thumb.height
          },
          at: new Date().toISOString()
        });

        if (!saved) {
          throw new Error('Could not persist result in this session. Please try again.');
        }

        window.setTimeout(function () {
          window.location.href = 'result.html';
        }, 520);
      })
      .catch(function (err) {
        state.busy = false;
        hideProcessing();
        if (dom.progressFill) dom.progressFill.classList.add('is-error');
        setActionButtonsDisabled(false);
        setAnalyzeEnabled(true);
        if (dom.analyze) {
          dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
        }
        var code = (err && err.code) || (scenario === 'error' ? 'SIMULATED_ERROR' : 'PREDICTION_FAILED');
        var message = (err && err.message) || (scenario === 'error'
          ? t('msg.demoSimulatedError', 'Simulasi gagal: Terjadi kesalahan yang disimulasikan untuk menguji penanganan error. Model tidak menghasilkan prediksi.')
          : t('msg.predictionFailed', 'Prediksi gagal. Coba lagi dengan gambar lain.'));
        showError(code, message);
        if (dom.mascot) FG.fruit.setMood(dom.mascot, 'sad');
      });
  }

  /**
   * Menjalankan analisis model normal untuk gambar upload perangkat atau jepretan kamera.
   */
  function executeStandardAnalysis() {
    return FG.api
      .predict(state.file)
      .then(function (result) {
        return FG.store.makeThumb(state.file, 900).then(function (thumb) {
          return { result: result, thumb: thumb };
        });
      })
      .then(function (payload) {
        finishProcessing();
        var saved = FG.store.save({
          result: payload.result,
          image: payload.thumb.dataUrl,
          file: {
            name: state.file.name || 'camera-capture.jpg',
            size: state.file.size,
            width: payload.thumb.width,
            height: payload.thumb.height
          },
          at: new Date().toISOString()
        });

        if (!saved) {
          throw new Error('Could not persist result in this session. Please try again.');
        }

        window.setTimeout(function () {
          window.location.href = 'result.html';
        }, 520);
      })
      .catch(function (err) {
        state.busy = false;
        hideProcessing();
        if (dom.progressFill) dom.progressFill.classList.add('is-error');
        setActionButtonsDisabled(false);
        setAnalyzeEnabled(true);
        if (dom.analyze) {
          dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
        }
        var code = (err && err.code) || (scenario === 'error' ? 'SIMULATED_ERROR' : 'PREDICTION_FAILED');
        var message = (err && err.message) || (scenario === 'error'
          ? t('msg.demoSimulatedError', 'Simulasi gagal: Terjadi kesalahan yang disimulasikan untuk menguji penanganan error. Model tidak menghasilkan prediksi.')
          : t('msg.predictionFailed', 'Prediksi gagal. Coba lagi dengan gambar lain.'));
        showError(code, message);
        if (dom.mascot) FG.fruit.setMood(dom.mascot, 'sad');
      });
  }

  /**
   * Hanya dipanggil saat pengguna mengklik tombol Pindai Buah.
   */
  function handleAnalyzeClick(e) {
    if (e) {
      if (typeof e.preventDefault === 'function') e.preventDefault();
      if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    if (state.busy || !state.file) return;

    state.busy = true;
    setAnalyzeEnabled(false);
    setActionButtonsDisabled(true);
    if (dom.analyzeHint) dom.analyzeHint.textContent = t('upload.hintBusy', 'Model is processing the image. Please keep this page open.');
    clearError();
    startProcessing();

    if (dom.analyze) {
      dom.analyze.classList.remove('is-ready');
      dom.analyze.innerHTML = '<span class="icon animate-spin" aria-hidden="true">progress_activity</span><span>' + FG.util.escapeHtml(t('upload.analyzingBtn', 'Memindai…')) + '</span>';
    }

    if (state.selectedDemoScenario) {
      executeDemoScenario(state.selectedDemoScenario);
      return;
    }

    executeStandardAnalysis();
  }

  // Alias untuk kompatibilitas
  var analyze = handleAnalyzeClick;

  /* ---------------- Demo Scenarios Binding ---------------- */
  function initDemo() {
    $$('[data-demo]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (state.busy) return;
        var scenario = btn.getAttribute('data-demo');
        var fruit = btn.getAttribute('data-fruit') || 'apple';
        selectDemoScenario(scenario, fruit, e);
      });
    });
  }

  /* ---------------- Language Change Observer ---------------- */
  function onLanguageChange() {
    if (state.file) {
      if (state.selectedDemoScenario === 'error') {
        if (dom.statusChip) {
          dom.statusChip.className = 'chip chip-demo';
          dom.statusChip.innerHTML = '<span class="icon text-[15px]">science</span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.demoErrorStatus', 'Skenario simulasi kegagalan')) + '</span>';
        }
        if (dom.previewCardTitle) {
          dom.previewCardTitle.textContent = t('upload.demoErrorCardTitle', 'Skenario simulasi kegagalan');
        }
        if (dom.analyzeHint) {
          dom.analyzeHint.textContent = state.busy ? t('upload.hintBusy', 'Model is processing the image. Please keep this page open.') : t('upload.hintDemoErrorReady', 'Skenario simulasi siap. Klik Pindai Buah untuk menguji simulasi kegagalan proses.');
        }
      } else {
        if (dom.statusChip) {
          dom.statusChip.className = 'chip chip-fresh';
          dom.statusChip.innerHTML = '<span class="icon text-[15px]">check_circle</span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.readyStatus', 'Gambar siap dianalisis')) + '</span>';
        }
        if (dom.previewCardTitle) {
          dom.previewCardTitle.textContent = t('upload.readyCardTitle', 'Gambar siap dianalisis');
        }
        if (dom.analyzeHint) {
          dom.analyzeHint.textContent = state.busy ? t('upload.hintBusy', 'Model is processing the image. Please keep this page open.') : t('upload.hintReady', 'Gambar siap dianalisis. Klik tombol untuk memulai pemindaian.');
        }
      }
      if (dom.analyze) {
        if (state.busy) {
          dom.analyze.innerHTML = '<span class="icon animate-spin" aria-hidden="true">progress_activity</span><span>' + FG.util.escapeHtml(t('upload.analyzingBtn', 'Memindai…')) + '</span>';
        } else {
          dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
        }
      }
    } else {
      if (dom.statusChip) {
        dom.statusChip.className = 'chip chip-neutral';
        dom.statusChip.innerHTML = '<span class="dot"></span> <span id="upload-status-text">' + FG.util.escapeHtml(t('upload.waitingStatus', 'Menunggu gambar')) + '</span>';
      }
      if (dom.previewCardTitle) {
        dom.previewCardTitle.textContent = t('upload.readyCardTitle', 'Gambar siap dianalisis');
      }
      if (dom.analyzeHint) {
        dom.analyzeHint.textContent = t('upload.hintEmpty', 'Pilih atau potret gambar terlebih dahulu untuk mengaktifkan pemindaian.');
      }
      if (dom.analyze) {
        dom.analyze.innerHTML = '<span class="icon text-[20px]" aria-hidden="true">document_scanner</span><span>' + FG.util.escapeHtml(t('upload.analyzeBtn', 'Pindai Buah')) + '</span>';
      }
    }

    if (dom.errorPanel && !dom.errorPanel.hidden && dom.errorCode) {
      var curCode = dom.errorCode.textContent.trim();
      if (dom.errorTitle) {
        var isFileCheck = /^(UNREADABLE_IMAGE|INVALID_FORMAT|EMPTY_FILE|FILE_TOO_LARGE|IMAGE_TOO_SMALL)$/.test(curCode || '');
        dom.errorTitle.textContent = isFileCheck
          ? t('upload.fileErrorTitle', 'Berkas tidak valid')
          : t('upload.errorTitle', 'Analisis gagal');
      }
      if (curCode === 'SIMULATED_ERROR' && dom.errorMessage) {
        dom.errorMessage.textContent = t('msg.demoSimulatedError', 'Simulasi gagal: Terjadi kesalahan yang disimulasikan untuk menguji penanganan error. Model tidak menghasilkan prediksi.');
      } else if (curCode === 'FILE_CORRUPTED' && dom.errorMessage) {
        dom.errorMessage.textContent = t('msg.demoCorruptedError', 'Simulasi gagal: Berkas gambar rusak atau korup sehingga tidak dapat dianalisis oleh model CNN. Silakan coba lagi dengan foto yang jelas.');
      } else if (curCode === 'UNREADABLE_IMAGE' && dom.errorMessage) {
        dom.errorMessage.textContent = t('msg.unreadableImage', 'Berkas gambar rusak atau korup sehingga tidak dapat dibaca. Silakan pilih foto lain dengan format JPG atau PNG yang jelas.');
      }
    }

    if (camera.isOpen) {
      camera.applyMirror();
    }
  }

  /* ---------------- Events Binding ---------------- */
  function bind() {
    // Normal file input
    if (dom.input) {
      dom.input.addEventListener('change', function (e) {
        if (e.target.files && e.target.files[0]) {
          state.selectedDemoScenario = null;
          if (FG.api) FG.api.forcedScenario = null;
          $$('[data-demo]').forEach(function (b) { b.removeAttribute('aria-pressed'); });
          handleFile(e.target.files[0]);
        }
      });
    }

    // Camera mobile fallback file input
    if (dom.cameraInput) {
      dom.cameraInput.addEventListener('change', function (e) {
        if (e.target.files && e.target.files[0]) {
          state.selectedDemoScenario = null;
          if (FG.api) FG.api.forcedScenario = null;
          $$('[data-demo]').forEach(function (b) { b.removeAttribute('aria-pressed'); });
          handleFile(e.target.files[0]);
        }
      });
    }

    // Tabs
    if (dom.tabUpload) {
      dom.tabUpload.addEventListener('click', function () {
        setTab('upload');
      });
    }

    if (dom.tabCamera) {
      dom.tabCamera.addEventListener('click', function () {
        camera.open();
      });
    }

    // Camera action buttons
    if (dom.btnCancelCamera) dom.btnCancelCamera.addEventListener('click', camera.close);
    if (dom.btnCaptureCamera) dom.btnCaptureCamera.addEventListener('click', camera.capture);
    if (dom.btnFlipCamera) dom.btnFlipCamera.addEventListener('click', camera.flip);
    if (dom.btnMirrorCamera) {
      dom.btnMirrorCamera.addEventListener('click', function () {
        camera.toggleMirror(false);
      });
    }
    if (dom.cameraMirrorChip) {
      dom.cameraMirrorChip.addEventListener('click', function (e) {
        e.stopPropagation();
        camera.toggleMirror(false);
      });
    }

    if (dom.btnCameraFallback) {
      dom.btnCameraFallback.addEventListener('click', function () {
        if (dom.cameraInput) dom.cameraInput.click();
      });
    }

    if (dom.btnCameraSwitchUpload) {
      dom.btnCameraSwitchUpload.addEventListener('click', function () {
        setTab('upload');
      });
    }

    // Retake from preview
    if (dom.retakeCamera) {
      dom.retakeCamera.addEventListener('click', function () {
        if (state.busy) return;
        camera.open();
        if (dom.viewCamera && window.innerWidth < 1024) {
          dom.viewCamera.scrollIntoView({ behavior: FG.util.prefersReduced() ? 'auto' : 'smooth', block: 'center' });
        }
      });
    }

    // Dropzone interactions
    if (dom.dropzone) {
      dom.dropzone.addEventListener('click', function () {
        if (state.busy) return;
        dom.input.click();
      });

      dom.dropzone.addEventListener('keydown', function (e) {
        if (state.busy) return;
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          dom.input.click();
        }
      });

      var dragDepth = 0;
      ['dragenter', 'dragover'].forEach(function (type) {
        dom.dropzone.addEventListener(type, function (e) {
          e.preventDefault();
          if (state.busy) return;
          if (type === 'dragenter') dragDepth += 1;
          dom.dropzone.classList.add('is-dragging');
          if (dom.mascot) FG.fruit.setMood(dom.mascot, 'excited');
        });
      });

      dom.dropzone.addEventListener('dragleave', function (e) {
        e.preventDefault();
        dragDepth = Math.max(0, dragDepth - 1);
        if (dragDepth === 0) {
          dom.dropzone.classList.remove('is-dragging');
          if (dom.mascot) FG.fruit.setMood(dom.mascot, null);
        }
      });

      dom.dropzone.addEventListener('drop', function (e) {
        e.preventDefault();
        dragDepth = 0;
        dom.dropzone.classList.remove('is-dragging');
        if (dom.mascot) FG.fruit.setMood(dom.mascot, null);
        if (state.busy) return;
        var files = e.dataTransfer && e.dataTransfer.files;
        if (files && files[0]) {
          state.selectedDemoScenario = null;
          if (FG.api) FG.api.forcedScenario = null;
          $$('[data-demo]').forEach(function (b) { b.removeAttribute('aria-pressed'); });
          handleFile(files[0]);
        }
      });
    }

    // Change image / Browse button
    if (dom.replace) {
      dom.replace.addEventListener('click', function () {
        if (state.busy) return;
        setTab('upload');
        dom.input.click();
      });
    }

    // Remove image
    if (dom.remove) {
      dom.remove.addEventListener('click', function () {
        if (state.busy) return;
        resetPreview();
        FG.util.toast(t('msg.imageRemoved', 'Image removed.'), { duration: 2200 });
      });
    }

    // Analyze Fruit & Retry
    if (dom.analyze) dom.analyze.addEventListener('click', analyze);
    if (dom.retry) dom.retry.addEventListener('click', analyze);

    // Keyboard controls when camera is active (Escape: Cancel, Space/Enter: Shutter)
    window.addEventListener('keydown', function (e) {
      if (!camera.isOpen) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        camera.close();
      } else if (e.key === ' ' || e.key === 'Enter') {
        if (document.activeElement && document.activeElement.tagName === 'BUTTON') return;
        e.preventDefault();
        camera.capture();
      }
    });

    // Cleanup resources when navigating away from the page
    window.addEventListener('beforeunload', camera.stopStream);
    window.addEventListener('pagehide', camera.stopStream);

    // Listen to language changes
    document.addEventListener('fg:langchange', onLanguageChange);
  }

  /* ---------------- Initialization ---------------- */
  function init() {
    cache();
    bind();
    resetPreview();
    setTab('upload');
    initDemo();

    var scenario = FG.config.scenario;
    if (scenario) {
      FG.api.forcedScenario = scenario;
      if (dom.statusChip) {
        dom.statusChip.className = 'chip chip-demo';
        dom.statusChip.innerHTML = '<span class="icon text-[15px]">science</span> Scenario: ' + FG.util.escapeHtml(scenario);
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
